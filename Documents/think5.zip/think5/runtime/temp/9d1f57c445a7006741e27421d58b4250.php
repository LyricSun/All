<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"/Library/WebServer/Documents/think5/public/../application/index/view/index/index.html";i:1515140891;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/think5/public/static/index/css/common.css">
</head>
<body>
    <div class="main">
        test
    </div>
</body>
</html>